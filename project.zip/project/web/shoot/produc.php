<?php error_reporting(0); ?>
<?session_start();
include("conn.php");
if($_SESSION['UserID'] == "")
{
		echo 'กรุณาเข้าสู่ระบบ';
		header("location:index.php");
exit();
}
?>

<!DOCTYPE html>
<html lang="en">
     <head>
     <title>About</title>
     <meta charset="utf-8">
     <link rel="icon" href="images/favicon.ico">
     <link rel="shortcut icon" href="images/favicon.ico" />
     <link rel="stylesheet" href="css/style.css">
	 <link href="style.css" rel="stylesheet" type="text/css" />
     <script src="js/jquery.js"></script>
     <link rel="stylesheet" href="css/productcss.css">
     <script src="js/jquery-migrate-1.1.1.js"></script>
     <script src="js/jquery.equalheights.js"></script>
     <script src="js/jquery.ui.totop.js"></script>
     <script src="js/jquery.easing.1.3.js"></script>
     <script>
        $(document).ready(function(){

          $().UItoTop({ easingType: 'easeOutQuart' });
        }) 
     </script>
     <!--[if lt IE 8]>
       <div style=' clear: both; text-align:center; position: relative;'>
         <a href="http://windows.microsoft.com/en-US/internet-explorer/products/ie/home?ocid=ie6_countdown_bannercode">
           <img src="http://storage.ie6countdown.com/assets/100/images/banners/warning_bar_0000_us.jpg" border="0" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today." />
         </a>

    <![endif]-->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <link rel="stylesheet" media="screen" href="css/ie.css">
    <![endif]-->
    <!--[if lt IE 10]>
      <script src="js/html5shiv.js"></script>
      <link rel="stylesheet" media="screen" href="css/ie1.css">
    <![endif]-->
    
     </head>
     <body  class="">

<!--==============================header=================================-->
   <header> 
   <div class="container_12">
   <div class="grid_12"> 
    <div class="socials">
      <a href="https://twitter.com/My_story_kat?s=07"></a>
      <a href="https://www.facebook.com/Kanokpanseni"></a>
      <a href="https://plus.google.com/u/0/discover"></a>
      <a href="https://www.pinterest.com/?autologin=true" class="last"></a>
    </div>
    <h1><a href="home.php">
	<center><img  src="https://www.festisite.com/static/partylogo/img/logos/nike.png"></h1>
    

<nav id="bt-menu" class="bt-menu">
        <a href="#" class="bt-menu-trigger"><span>Menu</span></a>
        <ul>
		<li class="bt-icon"><a href="home.php">หน้าแรก</a></li>
         <li class="current bt-icon"><a href="produc.php">สินค้า</a></li>
         <li class="bt-icon"><a href="cart.php">ตระกร้าสินค้า</a></li>
         <li class="bt-icon"><a href="confirm.php">ยืนยันคำสั่งซื้อ</a></li>
		 <li class="bt-icon"><a href="payment.php?o_id=0">แจ้งโอนการสั่งซื้อ</a></li>
		 <li class="bt-icon"><a href="checktracking.php?o_id=0">เช็คสถานะการจัดส่ง</a></li>
		 <li class="bt-icon "><a href="index.php">LOGOUT</a></li>
        </ul>
      </nav>
    
 <div class="clear"></div>

<div class="clear"></div>
          </div>
      </div>
</header>
<!--==============================Content=================================-->

<div class="content"><div class="ic">More Website Templates @ TemplateMonster.com - December 02, 2013!</div>
  <div class="container_12">
 
    <div class="grid_12">
      <h3 class="head1">The Product</h3>
    </div>
    <?php
  //connect db
  include("conn.php");
  $sql = "select * from product WHERE p_status='ลงขาย' order by p_id";  //เรียกข้อมูลจากตารางโปรดักมาแสดงทั้งหมด แสดงตามไอดี
  $result = mysqli_query($conn, $sql);
  while($row = mysqli_fetch_array($result))
  {	echo "<table>";
  	echo "<tr>";
	echo "<td><img src='img/" . $row["p_pic"] ." '><br> "
	. $row["p_name"] ."<br>" . $row["p_zise"] ." <br> "
	.number_format($row["p_price"],2).
	"<br><a href='product_detail.php?p_id=$row[p_id]'>คลิก</a></tr></table>";

  
  }
  ?>
    </div>
  </div>
</div>

<!--==============================footer=================================-->

<footer>    
  <div class="container_12">
    <div class="grid_6 prefix_3">
      <a href="show.php" class="f_logo"><img src="https://seeklogo.com/images/N/Nike-logo-DD910D27E8-seeklogo.com.png" alt=""></a>
      <div class="copy">
      &copy; 2017 | <a href="#">KANOKPAN SENI</a> <br> Website   designed by <a href="http://www.templatemonster.com/" rel="nofollow">TemplateMonster.com</a>
      </div>
    </div>
  </div>
</footer>
     <script>
      $(document).ready(function(){ 
         $(".bt-menu-trigger").toggle( 
          function(){
            $('.bt-menu').addClass('bt-menu-open'); 
          }, 
          function(){
            $('.bt-menu').removeClass('bt-menu-open'); 
          } 
        ); 
      }) 
    </script>
</body>
</html>