<?php
include("conn.php");

$sql = "INSERT INTO shootshop.customer (t_name_c,f_name_c,l_name_c,email_c,tel_c
,address_c,province_c,amphur_c,district_c,zipcode_c,username_c,password_c)
VALUES ('$_POST[title]','$_POST[name]','$_POST[lastname]','$_POST[email]','$_POST[tel]','$_POST[address]'
,'$_POST[province]','$_POST[amphur]','$_POST[district]','$_POST[zipcode]','$_POST[username]','$_POST[password]')";

if (mysqli_query($conn,$sql)) {
	
	header("location:index.php");
}else{
	echo "Error: ". $sql . "<br>". mysqli_error($conn);
}

mysqli_close($conn);
?>
