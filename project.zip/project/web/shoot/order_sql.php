<?php
include("conn.php");

$sql = "INSERT INTO shootshop.product 
			(p_id,p_name,p_zise,p_price,p_price_sell,p_number,p_pic,p_status)
		VALUES 
			('$_POST[p_id]',
			 '$_POST[p_name]',
			 '$_POST[p_zise]',
			 '$_POST[p_price]',
			 '$_POST[p_price_sell]',
			 '$_POST[p_number]', 
			 '$_POST[p_pic]','ลงขาย')";

if (mysqli_query($conn,$sql)) {
	echo "New record created successfully";
		header("location:managestock.php");
}else{
	echo "Error: ". $sql . "<br>". mysqli_error($conn);
}

mysqli_close($conn);
?>