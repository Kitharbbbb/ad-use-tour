<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">   
  <link rel="stylesheet" href="css/styleee.css">

</head>
		<body class="body-Login-back">
			<div class="wrapper">
				<div class="container">
					<form method="POST" action="check_login.php" class="form" >
					
							<label>ชื่อเข้าใช้งาน</label><br>
							
								<input type="text" class="login" name="txtUsername" required>
								
							<label>รหัสผ่าน</label><br>
							
								<input type="password" class="login" name="txtPassword" required>
								
							<button type="submit" id="login-button">Login</button>
					</form>                    
                </div>
            </div>
		</body>
</html>
