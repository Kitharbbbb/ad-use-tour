
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
      <link rel="stylesheet" href="css/styleee.css">
</head>
	<body>
		<div class="wrapper">
			<div class="container">
				
					<h1>Welcome</h1>
						<form method="POST" action="c_login.php" class="form" >
							<label>ชื่อเข้าใช้งาน</label><br>
								<input type="text" class="login" name="txtUsername" required>
								
							<label>รหัสผ่าน</label><br>
								<input type="password" class="login" name="txtPassword" required>
								
							<button type="submit" id="login-button">Login</button>
						</form>
						<center><a href="register.php">Register</a>||<a href="loginAdmin.php">Admin</a></center>
			</div>
		</div>
	</body>
</html>
