<?include"conn.php"?>

<?
$sql = "UPDATE product SET p_name='$_POST[p_name]',p_price='$_POST[p_price]',
p_price_sell='$_POST[p_price_sell]',p_number='$_POST[p_number]',p_status='$_POST[p_status]'  WHERE p_id=$_POST[p_id]";
$result = mysqli_query($conn, $sql);
if($result)
{
	
	echo "Save Done.";
	if($_POST[p_status]=='ลบ'){
	$sql = "DELETE FROM product WHERE p_id=$_POST[p_id]";
	$result = mysqli_query($conn, $sql);
	}
	header("location:managestock.php");

}
else
{
	echo "Error Save ['.$sql.']";
}

mysqli_close($conn);
?>