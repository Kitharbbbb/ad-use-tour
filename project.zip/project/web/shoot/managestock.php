<?php error_reporting(0); ?>
<?include"conn.php"?>
<?session_start();
if($_SESSION['Status'] != "ADMIN")
{
		echo 'กรุณาเข้าสู่ระบบ';
		header("location:index.php");
exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Core CSS - Include with every page -->
    <link href="assets/plugins/bootstrap/bootstrap.css" rel="stylesheet" />
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/plugins/pace/pace-theme-big-counter.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet" />
    <link href="assets/css/main-style.css" rel="stylesheet" />
    <!-- Page-Level CSS -->
    <link href="assets/plugins/morris/morris-0.4.3.min.css" rel="stylesheet" />
   </head>
<body>
    <!--  wrapper -->
     <div id="wrapper">
        <!-- navbar top -->
        <nav class="navbar navbar-default navbar-fixed-top" role="navigation" id="navbar">
            <!-- navbar-header -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="managestock.php?p_id=0.php">
                    <img src="assets/img/logo.png" alt="" />
                </a>
            </div>
            <!-- end navbar-header -->
            <!-- navbar-top-links -->
             <ul class="nav navbar-top-links navbar-right">      
                <li class="dropdown">
                    <a class="dropdown-toggle"  href="logout.php">
                        <i class="fa fa-user fa-3x"></i>
                    </a>
                </li>
            </ul>
        </nav>
        <nav class="navbar-default navbar-static-side" role="navigation">
            <!-- sidebar-collapse -->
            <div class="sidebar-collapse">
                <!-- side-menu -->
                <ul class="nav" id="side-menu">
                    <li>
                        <!-- user image section-->
                        <div class="user-section">
                            <div class="user-section-inner">
                                <img src="assets/img/user.jpg" alt="">
                            </div>
                            <div class="user-info">
                                <div>KANOKPAN <strong>SENI</strong></div>
                                <div class="user-text-online">
                                    <span class="user-circle-online btn btn-success btn-circle "></span>&nbsp;Online
                                </div>
                            </div>
                        </div>
                        <!--end user image section-->
                    </li>
                    <li class="sidebar-search">
                        <!-- search section-->
                        <div class="input-group custom-search-form">
                            <input type="text" class="form-control" placeholder="Search...">
                            <span class="input-group-btn">
                                <button class="btn btn-default" type="button">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                        </div>
                        <!--end search section-->
                    </li>
                    <li class="selected">
                        <a href="managestock.php?p_id=0.php"><i class="fa fa-edit fa-fw"></i>จัดการสินค้า</a>
                   
                  </li>
                    <li>
                        <a href="showorder.php"><i class="fa fa-edit fa-fw"></i>รับORDER</a>
                     </li>
					
                    <li>
                        <a href="order_from.php"><i class="fa fa-edit fa-fw"></i>เพิ่มสินค้า</a>
                    </li>
					
					  <li>
                        <a href="addtaking.php"><i class="fa fa-edit fa-fw"></i>จัดส่งสินค้า</a>
                    </li>

                </ul>
                <!-- end side-menu -->
            </div>
            <!-- end sidebar-collapse -->
        </nav>
        <!-- end navbar side -->
        <!--  page-wrapper -->
        <div id="page-wrapper">

            <div class="row">
                <!-- Page Header -->
                <div class="col-lg-12">
                    <h1 class="page-header">จัดการสินค้า</h1>
                </div>
                <!--End Page Header -->
            </div>
<div class="row">
                <div class="col-lg-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
						ตารางจัดการสินค้า
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
							<?
$sql = "SELECT * FROM product";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0){
	?><table class="table table-striped table-bordered table-hover" id="dataTables-example"><?
	echo"<tr><th>id</th>
	<th>ชื่อ</th>
	<th>ไซค์</th>
	<th>ราคาต้นทุน</th>
	<th>ราคาขาย</th>
	<th>จำนวน</th>
	<th>รูป</td>
	<th>สถานะ</td>
	<th>เวลาที่แก้ไข</th></tr>";
	while ($row = mysqli_fetch_assoc($result)){
		echo "<tr><td><a href='?p_id=$row[p_id]'>".$row["p_id"].
		"</td> <td>".$row["p_name"].
		"</td> <td>".$row["p_zise"].
		"</td> <td>".$row["p_price_sell"].
		"</td> <td>".$row["p_price"].
		"</td> <td>".$row["p_number"].
		"</td> <td>"."<img style='width:100px;' src='img/".$row['p_pic']."'/>".
		"</td> <td>".$row["p_status"].
		"</td> <td>".$row["p_time"].
		"</td> </a></td></tr>";
		
	}
} else {
	echo "ไม่มีข้อมูล<br><br>";
}
?>
          
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
                    </div>

<?

$sql = "SELECT * FROM product where p_id=$_GET[p_id]";
$result = $conn->query($sql);
$row = $result->fetch_assoc();

?>
						
						<div class="panel-heading">
										สินค้าที่เลือก
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
									<form role="form" action="managestocksql.php" method="post">
									<div class="form-group">
											<label>ID</label>
												<input class="form-control" type="text" name="p_id" value= "<?=$_GET["p_id"]?>" required>
                                        </div>
									<div class="form-group">
											<label>ชื่อสินค้า</label>
												<input class="form-control" type="text" name="p_name" value= "<?=$row["p_name"]?>" required>
                                        </div>
									<div class="form-group">
											<label>ราคาสินค้า (ขาย)</label>
												<input class="form-control" type="text" name="p_price_sell" value= "<?=$row["p_price_sell"]?>" required>
                                        </div>
									<div class="form-group">
											<label>ราคาสินค้า (ต้นทุน) </label>
												<input class="form-control" type="text" name="p_price" value= "<?=$row["p_price"]?>" required>
                                        </div>
									<div class="form-group">
											<label>จำนวนสินค้า </label>
												<input class="form-control" type="text" name="p_number" value= "<?=$row["p_number"]?>" required>
                                        </div>
									<div class="form-group">
                                            <label>สถานะ</label>
                                            <select class="form-control" name="p_status" >
												<option value="ลงขาย">ลงขาย</option>
												<option value="ไม่ลงขาย">ไม่ลงขาย</option>
												<option value="ลบ">ลบ</option>
                                            </select>
                                        </div>
								<button type="submit" class="btn btn-primary">แก้ไข</button>

</form>
                                    </div>

                                </div>

                            </div>
                            <!-- /.row -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!--End simple table example -->

                </div>

                

            </div>

            </div>
       </div>

    </div>
    <!-- end wrapper -->

    <!-- Core Scripts - Include with every page -->
    <script src="assets/plugins/jquery-1.10.2.js"></script>
    <script src="assets/plugins/bootstrap/bootstrap.min.js"></script>
    <script src="assets/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="assets/plugins/pace/pace.js"></script>
    <script src="assets/scripts/siminta.js"></script>
    <!-- Page-Level Plugin Scripts-->
    <script src="assets/plugins/morris/raphael-2.1.0.min.js"></script>
    <script src="assets/plugins/morris/morris.js"></script>
    <script src="assets/scripts/dashboard-demo.js"></script>

</body>

</html>
