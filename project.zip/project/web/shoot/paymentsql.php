<?php
include("conn.php");

$sql = "INSERT INTO shootshop.payment (o_id,pay_name,o_total,pay_d,pay_t)
VALUES ('$_POST[o_id]','$_POST[pay_name]','$_POST[o_total]','$_POST[pay_d]','$_POST[pay_t]')";

if (mysqli_query($conn,$sql)) {
	echo "New record created successfully";
}else{
	echo "Error: ". $sql . "<br>". mysqli_error($conn);
}
$sql = "UPDATE shootshop.order_head SET o_status='แจ้งโอนแล้ว' WHERE o_id='$_POST[o_id]'";
$result = mysqli_query($conn, $sql);



mysqli_close($conn);
?>
<script type="text/javascript">
	alert("<?php echo $msg;?>");
	window.location ='produc.php';
</script>