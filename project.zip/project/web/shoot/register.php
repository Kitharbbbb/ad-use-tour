<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<html>
    <head>
      <link rel="stylesheet" href="css/styleeee.css">

        <title>Drop Down menu เลือกจังหวัด, อำเภอ, ตำบล ของประเทศไทย โดย www.itangmo.com</title>
        
    </head>
    <script language=Javascript>
        function Inint_AJAX() {
           try { return new ActiveXObject("Msxml2.XMLHTTP");  } catch(e) {} //IE
           try { return new ActiveXObject("Microsoft.XMLHTTP"); } catch(e) {} //IE
           try { return new XMLHttpRequest();          } catch(e) {} //Native Javascript
           alert("XMLHttpRequest not supported");
           return null;
        };

        function dochange(src, val) {
             var req = Inint_AJAX();
             req.onreadystatechange = function () { 
                  if (req.readyState==4) {
                       if (req.status==200) {
                            document.getElementById(src).innerHTML=req.responseText; //รับค่ากลับมา
                       } 
                  }
             };
             req.open("GET", "localtion.php?data="+src+"&val="+val); //สร้าง connection
             req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8"); // set Header
             req.send(null); //ส่งค่า
        }

        window.onLoad=dochange('province', -1);     
    </script>
    <body>
       <div class="wrapper">
	   
	<div class="container"> 
		<br><br>
		<center><h1>Register</h1></center>
        <form name="form" method="post" action="registersql.php" >
	<center><table border="0" class="boxx" bgcolor="#3CB371">	
	<tr><td>ชื่อ :
			<select name="title" >
			<option value=" เด็กชาย">เด็กชาย</option>
			<option value="เด็กหญิง">เด็กหญิง</option>
			<option value="นาย">นาย</option>
			<option value="นาง">นาง</option>
			<option value="นางสาว">นางสาว</option>
	</select></td>
		<td><input type="text" name="name" class="textbox" required /></td>
	</tr>
	<tr>
		<td>นามสกุล : </td>
		<td><input type="text" name="lastname" class="textbox" required /></td>
	</tr>
	<tr>
		<td>e-mail:</td> 
		<td><input type="text" name="email" class="textbox" required /></td>
	</tr>
	<tr>
		<td>เบอรโทรศัพท์ </td>
		<td><input type="text" name="tel" maxlength="10" class="textbox" required /></td>
	</tr>
	<tr>
		<td>ที่อยู่ : </td>
		<td><input type="text" name="address" class="textbox" required /></td>
	</tr>
            <p>
               <tr><td> จังหวัด : </td>
                <td><span id="province" class="textbox">
                    <select name="province" >
                        <option value="0">- เลือกจังหวัด -</option>
                    </select>
                </span></td></tr>
            </p>
            <p>
              <tr><td>  อำเภอ : </td>
               <td> <span id="amphur" class="textbox">
                    <select name="amphur">
                        <option value='0'>- เลือกอำเภอ -</option>
                    </select>
                </span></td></tr>
            </p>
            <p>
               <tr><td>   ตำบล : </td>
                <td><span id="district" class="textbox" >
                    <select name="district">
                        <option value='0'>- เลือกตำบล -</option>
                    </select>
                </span></td></tr>
            </p>
			 <tr><td>รหัสไปรษณีย์ : </td>
					<td><input type="text" name="zipcode" class="textbox" required /></td></tr>
			 <tr><td>ชื่อผู้ใช้ : </td>
					<td><input type="text" name="username" class="textbox" required /></td></tr>
			 <tr><td>รหัสผ่าน :</td> 
					<td><input type="password" name="password"class="textbox" required /></td></tr>
			 
            <tr><td><input type="Submit" name="Submit" value="ตกลง" ></td> 
			
			<td><INPUT type="reset" value="ยกเลิก" ></td></tr>
			
        </form>
		<a href="index.php">
			<INPUT type="button" value="กลับหน้า login" font color="red" >
		</a>

    </body>
</html>
	</div>
	

</div>
