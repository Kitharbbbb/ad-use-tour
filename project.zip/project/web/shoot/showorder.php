<?php error_reporting(0); ?>
<?include"conn.php"?>
<?session_start();
if($_SESSION['Status'] != "ADMIN")
{
		echo 'กรุณาเข้าสู่ระบบ';
		header("location:index.php");
exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bootsrtap Free Admin Template - SIMINTA | Admin Dashboad Template</title>
    <!-- Core CSS - Include with every page -->
    <link href="assets/plugins/bootstrap/bootstrap.css" rel="stylesheet" />
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/plugins/pace/pace-theme-big-counter.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet" />
    <link href="assets/css/main-style.css" rel="stylesheet" />
    <!-- Page-Level CSS -->
    <link href="assets/plugins/morris/morris-0.4.3.min.css" rel="stylesheet" />
   </head>
<body>
    <!--  wrapper -->
     <div id="wrapper">
        <!-- navbar top -->
        <nav class="navbar navbar-default navbar-fixed-top" role="navigation" id="navbar">
            <!-- navbar-header -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="managestock.php?p_id=0.php">
                    <img src="assets/img/logo.png" alt="" />
                </a>
            </div>
             <ul class="nav navbar-top-links navbar-right">      
                <li class="dropdown">
                    <a class="dropdown-toggle"  href="logout.php">
                        <i class="fa fa-user fa-3x"></i>
                    </a>
                </li>
            </ul>
        </nav>
        <nav class="navbar-default navbar-static-side" role="navigation">
            <!-- sidebar-collapse -->
            <div class="sidebar-collapse">
                <!-- side-menu -->
                <ul class="nav" id="side-menu">
                    <li>
                        <!-- user image section-->
                        <div class="user-section">
                            <div class="user-section-inner">
                                <img src="assets/img/user.jpg" alt="">
                            </div>
                            <div class="user-info">
                                <div>KANOKPAN <strong>SENI</strong></div>
                                <div class="user-text-online">
                                    <span class="user-circle-online btn btn-success btn-circle "></span>&nbsp;Online
                                </div>
                            </div>
                        </div>
                        <!--end user image section-->
                    </li>
                    <li class="sidebar-search">
                        <!-- search section-->
                        <div class="input-group custom-search-form">
                            <input type="text" class="form-control" placeholder="Search...">
                            <span class="input-group-btn">
                                <button class="btn btn-default" type="button">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                        </div>
                        <!--end search section-->
                    </li>
                    <li >
                        <a href="managestock.php?p_id=0.php"><i class="fa fa-edit fa-fw"></i>จัดการสินค้า</a>
                    </li>
                  
                    <li class="selected">
                        <a href="showorder.php"><i class="fa fa-edit fa-fw"></i>รับORDER</a>
                     </li>
					
                    <li>
                        <a href="order_from.php"><i class="fa fa-edit fa-fw"></i>เพิ่มสินค้า</a>
                    </li>
					
					  <li>
                        <a href="addtaking.php"><i class="fa fa-edit fa-fw"></i>จัดส่งสินค้า</a>
                    </li>

                </ul>
                <!-- end side-menu -->
            </div>
            <!-- end sidebar-collapse -->
        </nav>
        <!-- end navbar side -->
        <!--  page-wrapper -->
        <div id="page-wrapper">

            <div class="row">
                <!-- Page Header -->
                <div class="col-lg-12">
                    <h1 class="page-header">จัดการสินค้า</h1>
                </div>
                <!--End Page Header -->
            </div>
<div class="row">
                <div class="col-lg-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
									ตารางจัดการสินค้า
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
<?
$sql = "SELECT * FROM order_head WHERE o_status='แจ้งโอนแล้ว'";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0){
	?><table class="table table-striped table-bordered table-hover" id="dataTables-example">;<?
	echo"<tr>
	<th>รหัสคำสั่งซื้อ</th>
	<th>เวลาสั่งซื้อ</th>
	<th>ชื้อลูกค้า</th>
	<th>ยอดรวมที่ลูกค้าต้องจ่าย</th>
	</tr>";
	while ($row = mysqli_fetch_assoc($result)){
		echo "<tr><td><a href='?o_id=$row[o_id]'>".$row["o_id"].
		"</td> <td>".$row["o_dttm"].
		"</td> <td>".$row["o_name"].
		"</td> <td>".$row["o_total"].
		"</td> </a></td></tr>";
	}
} else {
	echo "ไม่มีข้อมูล<br><br>";
}
?>
          
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
                    </div>
					  </div>
                    </div>
					  
               

<?

$sql = "SELECT * FROM order_head where o_id=$_GET[o_id]";
$result1 = $conn->query($sql);
$row1 = $result1->fetch_assoc();
?>

<div class="row">
                <div class="col-lg-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
									ข้อมูลรายละเอียด
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive"><?
        echo  " รหัสคำสั่งซื้อ : " .$row1["o_id"]. 
		" <br>เวลาสั่งซื้อ : " . $row1["o_dttm"].
		" <br>ชื้อลูกค้า : " . $row1["o_name"].
		" <br>ที่อยู่ลูกค้า : ". $row1["o_addr"].
		" <br>e-mail ลูกค้า  : ".$row1["o_email"].
		" <br>เบอร์โทรลูกค้า : ".$row1["o_phone"];

$sql = "SELECT a.*,b.* FROM order_detail a,product b where a.o_id=$row1[o_id] && a.p_id=b.p_id";
$result2 = $conn->query($sql);
?>

							</div>
                         </div>
                        </div>
                    </div>
					  </div>

					  <div class="row">
                <div class="col-lg-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
									ตารางรายละเอียดสินค้าที่ซื้อ
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
<?
$sql = "SELECT * FROM order_head WHERE o_status='แจ้งโอนแล้ว'";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0){
	?><table class="table table-striped table-bordered table-hover" id="dataTables-example"><?
	echo"<tr><th>ชื่อสินค้า</th>
	<th>จำนวน</th>
	<th>ราคา</th></tr>";

	
while ($row2 = mysqli_fetch_assoc($result2)){
		echo "<tr><td>".$row2["p_name"].
		"</td> <td>".$row2["d_qty"].
		"</td> <td>".$row2["d_subtotal"]."</td></td></tr>";
	
	}
} else {
	echo "ไม่มีข้อมูล<br><br>";
}
?>
          
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
                    </div>
					  </div>
                    </div>
<?
$sql = "SELECT * FROM payment where o_id=$_GET[o_id]";
$result3 = $conn->query($sql);
$row3 = $result3->fetch_assoc();?>

		<div class="row">
                <div class="col-lg-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
									ข้อมูลรายละเอียดการโอนเงิน
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive"><?
      echo  " ยอดรวมที่ลูกค้าแจ้งโอน : " . $row3["o_total"].
		" <br>ชื่อผู้โอน : " . $row3["pay_name"].
		" <br>วันที่โอน : " . $row3["pay_d"].
		" <br>เวลาที่โอน : ". $row3["pay_t"];

?>

							</div>
                         </div>
                   </div>
			   </div>
		</div> 
             
						<div class="row">
                <div class="col-lg-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
									ตรวจสอบยอดโอนเงิน
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
									<form role="form" action="showordersql.php" method="post">
									<div class="form-group">
											<label>รหัสคำสั่งซื้อ</label>
												<input class="form-control" type="text" name="o_id" value= "<?=$_GET["o_id"]?>" required>
                                        </div>
									<div class="form-group">
                                            <label>สถานะ</label>
                                            <select class="form-control" name="o_status" >
                                               <option value="ยอดโอนถูกต้อง">ยอดโอนถูกต้อง</option>
												<option value="ยกเลิกคำสั่งซื้อ">ยกเลิกคำสั่งซื้อ</option>
									
                                            </select>
                                        </div>
									
								<button type="submit" class="btn btn-primary">บันทึก</button>

</form>
                                    </div>

                                </div>			 
                    </div>
 </div>
    <!-- end wrapper -->

    <!-- Core Scripts - Include with every page -->
    <script src="assets/plugins/jquery-1.10.2.js"></script>
    <script src="assets/plugins/bootstrap/bootstrap.min.js"></script>
    <script src="assets/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="assets/plugins/pace/pace.js"></script>
    <script src="assets/scripts/siminta.js"></script>
    <!-- Page-Level Plugin Scripts-->
    <script src="assets/plugins/morris/raphael-2.1.0.min.js"></script>
    <script src="assets/plugins/morris/morris.js"></script>
    <script src="assets/scripts/dashboard-demo.js"></script>

</body>

</html>
