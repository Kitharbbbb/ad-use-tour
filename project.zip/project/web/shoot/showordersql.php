<?include"conn.php"?>

<?
$sql = "UPDATE order_head SET o_status='$_POST[o_status]'  WHERE o_id=$_POST[o_id]";
$result = mysqli_query($conn, $sql);

if($_POST[o_status]=='ยอดโอนถูกต้อง'){
$sql = "SELECT a.*,b.* FROM order_detail a,product b where a.o_id=$_POST[o_id] && a.p_id=b.p_id";
$result = $conn->query($sql);
while ($row = mysqli_fetch_assoc($result)){
		$p_id=$row["p_id"];
		$row["p_number"]=$row["p_number"]-$row["d_qty"];
		$c=$row["p_number"];
		$sql1 = "UPDATE product SET p_number='$c' WHERE p_id=$p_id";
		$result1 = mysqli_query($conn, $sql1);
	}

}


if($result)
{
	
	echo "Save Done.";
	header("location:managestock.php");
}
else
{
	echo "Error Save ['.$sql.']";
}

mysqli_close($conn);
?>